USE master;
GO
IF DB_ID('ComicsLand') IS NOT NULL
BEGIN
    ALTER DATABASE ComicsLand SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE ComicsLand;
END
GO
CREATE DATABASE ComicsLand;
GO
USE ComicsLand;
GO

CREATE TABLE Publishers (
    PublisherID INT IDENTITY(1,1) PRIMARY KEY,
    PublisherName NVARCHAR(100) NOT NULL,
    ContactPerson NVARCHAR(100) NULL,
    Phone NVARCHAR(20) NULL,
    Address NVARCHAR(200) NULL,
    Email NVARCHAR(100) UNIQUE NULL,
    Website NVARCHAR(255) NULL
);
GO

CREATE TABLE Comics (
    ComicID INT IDENTITY(1,1) PRIMARY KEY,
    Title NVARCHAR(200) NOT NULL,
    PublisherID INT NOT NULL,
    Author NVARCHAR(100) NULL,
    Series NVARCHAR(100) NULL,
    IssueNumber INT NULL,
    ReleaseDate DATE NULL,
    Genre NVARCHAR(50) NULL,
    Price DECIMAL(10,2) NOT NULL CHECK (Price >= 0),
    StockQuantity INT DEFAULT 0,
    CONSTRAINT FK_Comics_Publishers
        FOREIGN KEY (PublisherID)
        REFERENCES Publishers(PublisherID)
        ON DELETE CASCADE
);
GO

CREATE TABLE Deliveries (
    DeliveryID INT IDENTITY(1,1) PRIMARY KEY,
    ComicID INT NOT NULL,
    PublisherID INT NOT NULL,
    DeliveryDate DATETIME NOT NULL,
    Quantity INT NOT NULL CHECK (Quantity > 0),
    CostPerUnit DECIMAL(10,2) NOT NULL CHECK (CostPerUnit >= 0),
    DeliveryStatus NVARCHAR(20) DEFAULT 'Pending'
        CHECK (DeliveryStatus IN ('Pending', 'In Transit', 'Delivered', 'Cancelled')),
    Notes NVARCHAR(500) NULL,
    CONSTRAINT FK_Deliveries_Comics
        FOREIGN KEY (ComicID)
        REFERENCES Comics(ComicID)
        ON DELETE CASCADE,
    CONSTRAINT FK_Deliveries_Publishers
        FOREIGN KEY (PublisherID)
        REFERENCES Publishers(PublisherID)
        ON DELETE NO ACTION 
);
GO

CREATE TABLE Sales (
    SaleID INT IDENTITY(1,1) PRIMARY KEY,
    ComicID INT NOT NULL,
    SaleDate DATETIME NOT NULL,
    Quantity INT NOT NULL CHECK (Quantity > 0),
    UnitPrice DECIMAL(10,2) NOT NULL CHECK (UnitPrice >= 0),
    TotalAmount AS (Quantity * UnitPrice) PERSISTED,
    CustomerName NVARCHAR(100) NULL,
    CustomerEmail NVARCHAR(100) NULL,
    PaymentMethod NVARCHAR(50) NULL,
    SaleStatus NVARCHAR(20) DEFAULT 'Completed'
        CHECK (SaleStatus IN ('Pending', 'Completed', 'Cancelled', 'Returned')),
    CONSTRAINT FK_Sales_Comics
        FOREIGN KEY (ComicID)
        REFERENCES Comics(ComicID)
        ON DELETE CASCADE
);
GO

INSERT INTO Publishers (PublisherName, ContactPerson, Phone, Address, Email, Website)
VALUES
    ('Marvel Comics', 'John Smith', '+1(212)555-1234', '135 W 50th St, New York, NY', 'contact@marvel.com', 'www.marvel.com'),
    ('DC Comics', 'Jane Doe', '+1(212)555-5678', '1700 Broadway, New York, NY', 'contact@dccomics.com', 'www.dccomics.com'),
    ('Image Comics', 'Robert Kirkman', '+1(310)555-9012', '1122 W Olympic Blvd, Los Angeles, CA', 'info@imagecomics.com', 'www.imagecomics.com');
GO

INSERT INTO Comics (Title, PublisherID, Author, Series, IssueNumber, ReleaseDate, Genre, Price, StockQuantity)
VALUES
    ('Spider-Man: Blue', 1, 'Jeph Loeb', 'Spider-Man', 1, '2002-07-03', 'Superhero', 12.99, 50),
    ('Batman: The Killing Joke', 2, 'Alan Moore', 'Batman', 1, '1988-03-01', 'Superhero', 17.99, 30),
    ('The Walking Dead, Vol. 1', 3, 'Robert Kirkman', 'The Walking Dead', 1, '2004-05-05', 'Horror', 9.99, 40),
    ('Iron Man: Extremis', 1, 'Warren Ellis', 'Iron Man', 1, '2005-04-06', 'Superhero', 14.99, 25),
    ('Watchmen', 2, 'Alan Moore', 'Watchmen', 1, '1986-09-01', 'Superhero', 24.99, 20);
GO

INSERT INTO Deliveries (ComicID, PublisherID, DeliveryDate, Quantity, CostPerUnit, DeliveryStatus, Notes)
VALUES
    (1, 1, '2025-09-01 00:00:00', 20, 8.00, 'Delivered', '���������� � ����'),
    (2, 2, '2025-09-02 00:00:00', 15, 12.00, 'Delivered', '���������� � ����������'),
    (3, 3, '2025-09-03 00:00:00', 30, 6.00, 'In Transit', NULL),
    (4, 1, '2025-09-04 00:00:00', 10, 9.50, 'Pending', NULL),
    (5, 2, '2025-09-05 00:00:00', 5, 15.00, 'Cancelled', '������������ ������');
GO

INSERT INTO Sales (ComicID, SaleDate, Quantity, UnitPrice, CustomerName, CustomerEmail, PaymentMethod, SaleStatus)
VALUES
    (1, '2025-09-10 00:00:00', 2, 12.99, '���� ������', 'ivan@mail.ru', 'Cash', 'Completed'),
    (2, '2025-09-11 00:00:00', 1, 17.99, '���� ������', 'petr@mail.ru', 'Card', 'Completed'),
    (3, '2025-09-12 00:00:00', 3, 9.99, '����� �������', 'sidor@mail.ru', 'Cash', 'Completed'),
    (1, '2025-09-13 00:00:00', 1, 12.99, '����� ���������', 'maria@mail.ru', 'Card', 'Pending'),
    (4, '2025-09-14 00:00:00', 1, 14.99, '���� ���������', 'anna@mail.ru', 'Cash', 'Completed');
GO

SELECT * FROM Publishers;
GO
SELECT * FROM Comics;
GO
SELECT * FROM Deliveries;
GO
SELECT * FROM Sales;
GO

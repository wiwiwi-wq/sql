SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE DATABASE puppi;
GO

USE puppi;
GO

CREATE TABLE [dbo].[AgentType](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [Title] [nvarchar](50) NOT NULL,
    [Image] [nvarchar](100) NULL,
 CONSTRAINT [PK_AgentType] PRIMARY KEY CLUSTERED ([ID] ASC)
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Agent](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [Title] [nvarchar](150) NOT NULL,
    [AgentTypeID] [int] NOT NULL,
    [Address] [nvarchar](300) NULL,
    [INN] [varchar](12) NOT NULL CONSTRAINT [UQ_Agent_INN] UNIQUE,
    [KPP] [varchar](9) NULL,
    [DirectorName] [nvarchar](100) NULL,
    [Phone] [nvarchar](20) NOT NULL,
    [Email] [nvarchar](255) NULL,
    [Logo] [nvarchar](100) NULL,
    [Priority] [int] NOT NULL CONSTRAINT [CK_Agent_Priority] CHECK ([Priority] >= 0) DEFAULT 0,
 CONSTRAINT [PK_Agent] PRIMARY KEY CLUSTERED ([ID] ASC)
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Agent_AgentTypeID] ON [dbo].[Agent] ([AgentTypeID]);
GO

CREATE TABLE [dbo].[AgentPriorityHistory](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [AgentID] [int] NOT NULL,
    [ChangeDate] [date] NOT NULL,
    [PriorityValue] [int] NOT NULL CONSTRAINT [CK_AgentPriorityHistory_PriorityValue] CHECK ([PriorityValue] >= 0),
 CONSTRAINT [PK_AgentPriorityHistory] PRIMARY KEY CLUSTERED ([ID] ASC)
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_AgentPriorityHistory_AgentID] ON [dbo].[AgentPriorityHistory] ([AgentID]);
GO

CREATE TABLE [dbo].[MaterialType](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [Title] [nvarchar](50) NOT NULL,
    [DefectedPercent] [float] NOT NULL CONSTRAINT [CK_MaterialType_DefectedPercent] CHECK ([DefectedPercent] >= 0),
 CONSTRAINT [PK_MaterialType] PRIMARY KEY CLUSTERED ([ID] ASC)
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Material](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [Title] [nvarchar](100) NOT NULL,
    [CountInPack] [int] NOT NULL CONSTRAINT [CK_Material_CountInPack] CHECK ([CountInPack] > 0),
    [Unit] [nvarchar](10) NOT NULL,
    [CountInStock] [decimal](10,2) NULL DEFAULT 0.0,
    [MinCount] [decimal](10,2) NOT NULL CONSTRAINT [CK_Material_MinCount] CHECK ([MinCount] >= 0),
    [Description] [nvarchar](max) NULL,
    [Cost] [decimal](10,2) NOT NULL CONSTRAINT [CK_Material_Cost] CHECK ([Cost] >= 0),
    [Image] [nvarchar](100) NULL,
    [MaterialTypeID] [int] NOT NULL,
 CONSTRAINT [PK_Material] PRIMARY KEY CLUSTERED ([ID] ASC)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Material_MaterialTypeID] ON [dbo].[Material] ([MaterialTypeID]);
GO

CREATE TABLE [dbo].[MaterialCountHistory](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [MaterialID] [int] NOT NULL,
    [ChangeDate] [date] NOT NULL,
    [CountValue] [decimal](10,2) NOT NULL CONSTRAINT [CK_MaterialCountHistory_CountValue] CHECK ([CountValue] >= 0),
 CONSTRAINT [PK_MaterialCountHistory] PRIMARY KEY CLUSTERED ([ID] ASC)
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_MaterialCountHistory_MaterialID] ON [dbo].[MaterialCountHistory] ([MaterialID]);
GO

CREATE TABLE [dbo].[Supplier](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [Title] [nvarchar](150) NOT NULL,
    [INN] [varchar](12) NOT NULL CONSTRAINT [UQ_Supplier_INN] UNIQUE,
    [StartDate] [date] NOT NULL,
    [QualityRating] [int] NULL CONSTRAINT [CK_Supplier_QualityRating] CHECK ([QualityRating] >= 0 AND [QualityRating] <= 100),
    [SupplierType] [nvarchar](20) NULL,
 CONSTRAINT [PK_Supplier] PRIMARY KEY CLUSTERED ([ID] ASC)
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[MaterialSupplier](
    [MaterialID] [int] NOT NULL,
    [SupplierID] [int] NOT NULL,
 CONSTRAINT [PK_MaterialSupplier] PRIMARY KEY CLUSTERED ([MaterialID] ASC, [SupplierID] ASC)
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ProductType](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [Title] [nvarchar](50) NOT NULL,
    [DefectedPercent] [float] NOT NULL CONSTRAINT [CK_ProductType_DefectedPercent] CHECK ([DefectedPercent] >= 0),
 CONSTRAINT [PK_ProductType] PRIMARY KEY CLUSTERED ([ID] ASC)
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Product](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [Title] [nvarchar](100) NOT NULL,
    [ProductTypeID] [int] NULL,
    [ArticleNumber] [nvarchar](10) NOT NULL CONSTRAINT [UQ_Product_ArticleNumber] UNIQUE,
    [Description] [nvarchar](max) NULL,
    [Image] [nvarchar](100) NULL,
    [ProductionPersonCount] [int] NULL CONSTRAINT [CK_Product_ProductionPersonCount] CHECK ([ProductionPersonCount] >= 0),
    [ProductionWorkshopNumber] [int] NULL CONSTRAINT [CK_Product_ProductionWorkshopNumber] CHECK ([ProductionWorkshopNumber] >= 0),
    [MinCostForAgent] [decimal](10,2) NOT NULL CONSTRAINT [CK_Product_MinCostForAgent] CHECK ([MinCostForAgent] >= 0),
 CONSTRAINT [PK_Product] PRIMARY KEY CLUSTERED ([ID] ASC)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Product_ProductTypeID] ON [dbo].[Product] ([ProductTypeID]);
GO

CREATE TABLE [dbo].[ProductCostHistory](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [ProductID] [int] NOT NULL,
    [ChangeDate] [date] NOT NULL,
    [CostValue] [decimal](10,2) NOT NULL CONSTRAINT [CK_ProductCostHistory_CostValue] CHECK ([CostValue] >= 0),
 CONSTRAINT [PK_ProductCostHistory] PRIMARY KEY CLUSTERED ([ID] ASC)
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ProductCostHistory_ProductID] ON [dbo].[ProductCostHistory] ([ProductID]);
GO

CREATE TABLE [dbo].[ProductMaterial](
    [ProductID] [int] NOT NULL,
    [MaterialID] [int] NOT NULL,
    [Count] [decimal](10,2) NULL CONSTRAINT [CK_ProductMaterial_Count] CHECK ([Count] >= 0),
 CONSTRAINT [PK_ProductMaterial] PRIMARY KEY CLUSTERED ([ProductID] ASC, [MaterialID] ASC)
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ProductSale](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [AgentID] [int] NOT NULL,
    [ProductID] [int] NOT NULL,
    [SaleDate] [date] NOT NULL,
    [ProductCount] [int] NOT NULL CONSTRAINT [CK_ProductSale_ProductCount] CHECK ([ProductCount] > 0),
 CONSTRAINT [PK_ProductSale] PRIMARY KEY CLUSTERED ([ID] ASC)
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ProductSale_AgentID_ProductID] ON [dbo].[ProductSale] ([AgentID], [ProductID]);
GO

CREATE TABLE [dbo].[Shop](
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [Title] [nvarchar](150) NOT NULL,
    [Address] [nvarchar](300) NULL,
    [AgentID] [int] NOT NULL,
 CONSTRAINT [PK_Shop] PRIMARY KEY CLUSTERED ([ID] ASC)
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Shop_AgentID] ON [dbo].[Shop] ([AgentID]);
GO

ALTER TABLE [dbo].[Agent] WITH CHECK ADD CONSTRAINT [FK_Agent_AgentType] FOREIGN KEY([AgentTypeID]) REFERENCES [dbo].[AgentType] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Agent] CHECK CONSTRAINT [FK_Agent_AgentType]
GO
ALTER TABLE [dbo].[Agent] CHECK CONSTRAINT [FK_Agent_AgentType]
GO

ALTER TABLE [dbo].[AgentPriorityHistory] WITH CHECK ADD CONSTRAINT [FK_AgentPriorityHistory_Agent] FOREIGN KEY([AgentID])
REFERENCES [dbo].[Agent] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AgentPriorityHistory] CHECK CONSTRAINT [FK_AgentPriorityHistory_Agent]
GO

ALTER TABLE [dbo].[Material] WITH CHECK ADD CONSTRAINT [FK_Material_MaterialType] FOREIGN KEY([MaterialTypeID])
REFERENCES [dbo].[MaterialType] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Material] CHECK CONSTRAINT [FK_Material_MaterialType]
GO

ALTER TABLE [dbo].[MaterialCountHistory] WITH CHECK ADD CONSTRAINT [FK_MaterialCountHistory_Material] FOREIGN KEY([MaterialID])
REFERENCES [dbo].[Material] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[MaterialCountHistory] CHECK CONSTRAINT [FK_MaterialCountHistory_Material]
GO

ALTER TABLE [dbo].[MaterialSupplier] WITH CHECK ADD CONSTRAINT [FK_MaterialSupplier_Material] FOREIGN KEY([MaterialID])
REFERENCES [dbo].[Material] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[MaterialSupplier] CHECK CONSTRAINT [FK_MaterialSupplier_Material]
GO

ALTER TABLE [dbo].[MaterialSupplier] WITH CHECK ADD CONSTRAINT [FK_MaterialSupplier_Supplier] FOREIGN KEY([SupplierID])
REFERENCES [dbo].[Supplier] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[MaterialSupplier] CHECK CONSTRAINT [FK_MaterialSupplier_Supplier]
GO

ALTER TABLE [dbo].[Product] WITH CHECK ADD CONSTRAINT [FK_Product_ProductType] FOREIGN KEY([ProductTypeID])
REFERENCES [dbo].[ProductType] ([ID])
ON DELETE SET NULL
GO
ALTER TABLE [dbo].[Product] CHECK CONSTRAINT [FK_Product_ProductType]
GO

ALTER TABLE [dbo].[ProductCostHistory] WITH CHECK ADD CONSTRAINT [FK_ProductCostHistory_Product] FOREIGN KEY([ProductID])
REFERENCES [dbo].[Product] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ProductCostHistory] CHECK CONSTRAINT [FK_ProductCostHistory_Product]
GO

ALTER TABLE [dbo].[ProductMaterial] WITH CHECK ADD CONSTRAINT [FK_ProductMaterial_Material] FOREIGN KEY([MaterialID])
REFERENCES [dbo].[Material] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ProductMaterial] CHECK CONSTRAINT [FK_ProductMaterial_Material]
GO

ALTER TABLE [dbo].[ProductMaterial] WITH CHECK ADD CONSTRAINT [FK_ProductMaterial_Product] FOREIGN KEY([ProductID])
REFERENCES [dbo].[Product] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ProductMaterial] CHECK CONSTRAINT [FK_ProductMaterial_Product]
GO

ALTER TABLE [dbo].[ProductSale] WITH CHECK ADD CONSTRAINT [FK_ProductSale_Agent] FOREIGN KEY([AgentID])
REFERENCES [dbo].[Agent] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ProductSale] CHECK CONSTRAINT [FK_ProductSale_Agent]
GO

ALTER TABLE [dbo].[ProductSale] WITH CHECK ADD CONSTRAINT [FK_ProductSale_Product] FOREIGN KEY([ProductID])
REFERENCES [dbo].[Product] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ProductSale] CHECK CONSTRAINT [FK_ProductSale_Product]
GO

ALTER TABLE [dbo].[Shop] WITH CHECK ADD CONSTRAINT [FK_Shop_Agent] FOREIGN KEY([AgentID])
REFERENCES [dbo].[Agent] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Shop] CHECK CONSTRAINT [FK_Shop_Agent]
GO

CREATE TRIGGER TR_Agent_Priority_Update
ON [dbo].[Agent]
AFTER UPDATE
AS
BEGIN
    IF UPDATE(Priority)
    BEGIN
        INSERT INTO [dbo].[AgentPriorityHistory] ([AgentID], [ChangeDate], [PriorityValue])
        SELECT inserted.ID, GETDATE(), inserted.Priority
        FROM inserted
    END
END
GO

CREATE TRIGGER TR_Material_Count_Update
ON [dbo].[Material]
AFTER UPDATE
AS
BEGIN
    IF UPDATE(CountInStock)
    BEGIN
        INSERT INTO [dbo].[MaterialCountHistory] ([MaterialID], [ChangeDate], [CountValue])
        SELECT inserted.ID, GETDATE(), inserted.CountInStock
        FROM inserted
    END
END
GO

BULK INSERT [dbo].[Material]
FROM 'C:\Users\�������������\materials.csv' 
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2  
);
GO

BULK INSERT [dbo].[Supplier]
FROM 'C:\Users\�������������\supplier.txt'
WITH (
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '\n',
    FIRSTROW = 2
);
GO

INSERT INTO [dbo].[MaterialSupplier] ([MaterialID], [SupplierID])
SELECT DISTINCT MaterialID, SupplierID
FROM OPENROWSET(
    'Microsoft.ACE.OLEDB.12.0',
    'Excel 12.0;Database=C:\Users\�������������\Downloads\materialsupplier.xlsx;HDR=YES',
    'SELECT MaterialID, SupplierID FROM [Sheet1$]'
);
GO

INSERT INTO [dbo].[AgentType] ([Title], [Image]) VALUES
(N'���', NULL),
(N'��', NULL),
(N'���', NULL),
(N'���', NULL),
(N'��', NULL),
(N'�����������', NULL);
GO

INSERT INTO [dbo].[MaterialType] ([Title], [DefectedPercent]) VALUES
(N'�������', 0.0),
(N'������', 0.0),
(N'�����', 0.0);
GO

INSERT INTO [dbo].[MaterialCountHistory] ([MaterialID], [ChangeDate], [CountValue])
SELECT ID, '2025-10-07', CountInStock FROM [dbo].[Material];
GO

INSERT INTO [dbo].[AgentPriorityHistory] ([AgentID], [ChangeDate], [PriorityValue])
SELECT ID, '2025-10-07', Priority FROM [dbo].[Agent];
GO

INSERT INTO [dbo].[Product] (
    [Title], 
    [ProductTypeID], 
    [ArticleNumber], 
    [Description], 
    [Image], 
    [ProductionPersonCount], 
    [ProductionWorkshopNumber], 
    [MinCostForAgent]
)
VALUES
    (N'������� 1', 1, N'ART001', N'�������� �������� 1', NULL, 5, 1, 100.00),
    (N'������� 2', 1, N'ART002', N'�������� �������� 2', NULL, 6, 1, 120.00),
    (N'������� 3', 2, N'ART003', N'�������� �������� 3', NULL, 7, 2, 130.00),
    (N'������� 4', 2, N'ART004', N'�������� �������� 4', NULL, 8, 2, 140.00),
    (N'������� 5', 3, N'ART005', N'�������� �������� 5', NULL, 5, 3, 150.00),
    (N'������� 6', 3, N'ART006', N'�������� �������� 6', NULL, 6, 3, 160.00),
    (N'������� 7', 4, N'ART007', N'�������� �������� 7', NULL, 7, 4, 170.00),
    (N'������� 8', 4, N'ART008', N'�������� �������� 8', NULL, 8, 4, 180.00),
    (N'������� 9', 5, N'ART009', N'�������� �������� 9', NULL, 5, 5, 190.00),
    (N'������� 10', 5, N'ART010', N'�������� �������� 10', NULL, 6, 5, 200.00),
    (N'������� 11', 1, N'ART011', N'�������� �������� 11', NULL, 7, 1, 210.00),
    (N'������� 12', 2, N'ART012', N'�������� �������� 12', NULL, 8, 2, 220.00),
    (N'������� 13', 3, N'ART013', N'�������� �������� 13', NULL, 5, 3, 230.00),
    (N'������� 14', 4, N'ART014', N'�������� �������� 14', NULL, 6, 4, 240.00),
    (N'������� 15', 5, N'ART015', N'�������� �������� 15', NULL, 7, 5, 250.00),
    (N'������� 16', 1, N'ART016', N'�������� �������� 16', NULL, 8, 1, 260.00),
    (N'������� 17', 2, N'ART017', N'�������� �������� 17', NULL, 5, 2, 270.00),
    (N'������� 18', 3, N'ART018', N'�������� �������� 18', NULL, 6, 3, 280.00),
    (N'������� 19', 4, N'ART019', N'�������� �������� 19', NULL, 7, 4, 290.00),
    (N'������� 20', 5, N'ART020', N'�������� �������� 20', NULL, 8, 5, 300.00);
GO

INSERT INTO [dbo].[ProductCostHistory] ([ProductID], [ChangeDate], [CostValue])
SELECT ID, '2025-10-07', MinCostForAgent FROM [dbo].[Product];
GO

WITH RankedMaterials AS (
    SELECT 
        p.ID AS ProductID, 
        m.ID AS MaterialID,
        ROW_NUMBER() OVER (PARTITION BY p.ID ORDER BY NEWID()) AS rn,
        CAST(RAND(CHECKSUM(NEWID())) * 10 + 1 AS DECIMAL(10,2)) AS CountValue
    FROM [dbo].[Product] p
    CROSS JOIN [dbo].[Material] m
    WHERE NOT EXISTS (
        SELECT 1 
        FROM [dbo].[ProductMaterial] pm 
        WHERE pm.ProductID = p.ID AND pm.MaterialID = m.ID
    )
)
INSERT INTO [dbo].[ProductMaterial] ([ProductID], [MaterialID], [Count])
SELECT ProductID, MaterialID, CountValue
FROM RankedMaterials
WHERE rn <= 3;
GO

INSERT INTO [dbo].[ProductSale] ([AgentID], [ProductID], [SaleDate], [ProductCount])
SELECT a.ID, p.ID, DATEADD(DAY, CAST(RAND() * 365 AS INT), '2025-01-01'), CAST(RAND() * 100 + 1 AS INT)
FROM [dbo].[Agent] a
CROSS JOIN (SELECT TOP 2 ID FROM [dbo].[Product] ORDER BY NEWID()) p;  
GO

INSERT INTO [dbo].[Shop] ([Title], [Address], [AgentID])
SELECT N'������� ' + CAST(ROW_NUMBER() OVER (ORDER BY a.ID) AS NVARCHAR), N'����� ' + CAST(ROW_NUMBER() OVER (ORDER BY a.ID) AS NVARCHAR), a.ID
FROM [dbo].[Agent] a
CROSS JOIN (SELECT TOP 2 * FROM (VALUES(1),(2)) AS t(n)) t;  
GO

CREATE VIEW SalesByAgent AS
SELECT a.Title AS Agent, SUM(ps.ProductCount) AS TotalSales, SUM(ps.ProductCount * p.MinCostForAgent) AS TotalRevenue
FROM [dbo].[ProductSale] ps
JOIN [dbo].[Agent] a ON ps.AgentID = a.ID
JOIN [dbo].[Product] p ON ps.ProductID = p.ID
GROUP BY a.Title;
GO

CREATE VIEW SupplierEfficiency AS
SELECT s.Title AS Supplier, s.QualityRating, COUNT(ms.MaterialID) AS MaterialsSupplied
FROM [dbo].[Supplier] s
JOIN [dbo].[MaterialSupplier] ms ON s.ID = ms.SupplierID
GROUP BY s.Title, s.QualityRating;
GO

CREATE VIEW MaterialTurnover AS
SELECT m.Title, m.CountInStock, m.MinCount, (m.CountInStock / m.MinCount) AS TurnoverRatio
FROM [dbo].[Material] m
WHERE m.CountInStock > 0;
GO

CREATE VIEW ProductionProfitability AS
SELECT p.Title, p.MinCostForAgent AS AgentCost, SUM(pm.Count * mat.Cost) AS MaterialCost, (p.MinCostForAgent - SUM(pm.Count * mat.Cost)) AS ProfitMargin
FROM [dbo].[Product] p
JOIN [dbo].[ProductMaterial] pm ON p.ID = pm.ProductID
JOIN [dbo].[Material] mat ON pm.MaterialID = mat.ID
GROUP BY p.Title, p.MinCostForAgent;
GO

CREATE PROCEDURE CalculateAgentDiscount
    @AgentID INT
AS
BEGIN
    DECLARE @TotalSales INT;
    SELECT @TotalSales = SUM(ProductCount) FROM [dbo].[ProductSale] WHERE AgentID = @AgentID;
    
    DECLARE @Discount FLOAT;
    IF @TotalSales > 1000 SET @Discount = 0.15; 
    ELSE IF @TotalSales > 500 SET @Discount = 0.10;
    ELSE SET @Discount = 0.05;
    
    SELECT @Discount AS Discount;
END
GO

CREATE PROCEDURE CheckLowStock
AS
BEGIN
    SELECT Title, CountInStock, MinCount
    FROM [dbo].[Material]
    WHERE CountInStock < MinCount;
END
GO

SELECT * FROM [dbo].[AgentType];
GO
SELECT * FROM [dbo].[Agent];
GO
SELECT * FROM [dbo].[AgentPriorityHistory];
GO
SELECT * FROM [dbo].[MaterialType];
GO
SELECT * FROM [dbo].[Material];
GO
SELECT * FROM [dbo].[MaterialCountHistory];
GO
SELECT * FROM [dbo].[Supplier];
GO
SELECT * FROM [dbo].[MaterialSupplier];
GO
SELECT * FROM [dbo].[ProductType];
GO
SELECT * FROM [dbo].[Product];
GO
SELECT * FROM [dbo].[ProductCostHistory];
GO
SELECT * FROM [dbo].[ProductMaterial];
GO
SELECT * FROM [dbo].[ProductSale];
GO
SELECT * FROM [dbo].[Shop];
GO

SELECT CustomerNO, CustomerName, Address1, City FROM Customers;
SELECT * FROM Orders;
ALTER TABLE Customers 
ADD                  
NewFild int NULL     
GO

ALTER TABLE Customers 
DROP COLUMN           
NewFild               
GO
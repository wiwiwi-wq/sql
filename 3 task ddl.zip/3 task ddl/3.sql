ALTER DATABASE ShopDB
 MODIFY FILE				
( 
  NAME = 'ShopDB',
  MAXSIZE = 10MB	
)	  
GO
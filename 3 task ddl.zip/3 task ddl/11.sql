ALTER TABLE Customers 
ADD					 
NewFild2 varchar(10) NOT NULL 

GO
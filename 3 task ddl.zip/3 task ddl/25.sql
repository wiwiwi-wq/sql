SELECT * FROM Customers;
SELECT * FROM Orders;
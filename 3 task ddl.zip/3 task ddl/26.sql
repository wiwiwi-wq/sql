﻿ALTER TABLE Orders
DROP CONSTRAINT FK_CustomersCustomerNo;
GO
 
ALTER TABLE Orders
ADD CONSTRAINT FK_CustomersCustomerNo
FOREIGN KEY (CustomerNo) REFERENCES Customers(CustomerNo)
	ON DELETE SET NULL 
GO

DELETE Customers
WHERE CustomerName = 'Ïåòðåíêî Ïåòð Ïåòðîâè÷';
GO

SELECT * FROM Customers;
SELECT * FROM Orders;
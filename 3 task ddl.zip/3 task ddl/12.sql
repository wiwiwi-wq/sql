ALTER TABLE Customers 
ADD						
NewFild2 varchar(10) NOT NULL 
DEFAULT 'Unknown'
GO
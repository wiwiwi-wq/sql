ALTER TABLE Customers
NOCHECK CONSTRAINT CN_CustomersPhoneNo;		

INSERT INTO Customers
(CustomerName, Address1, City, Contact, Phone)
VALUES
('Alex', 'NewSTR', 'City', 'dfgjs@mail.ru', '(093)*******');
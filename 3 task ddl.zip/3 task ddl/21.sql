ALTER TABLE Orders
ADD CONSTRAINT FK_CustomersCustomerNo
FOREIGN KEY (CustomerNo) REFERENCES Customers(CustomerNo);										
GO

ALTER TABLE Orders
DROP CONSTRAINT FK_CustomersCustomerNo;
GO

DROP TABLE Customers; 
GO
USE ShopDB
GO
CREATE TABLE Customers                 
(	                                     
	CustomerNo int IDENTITY(1, 2) NOT NULL,  
	CustomerName varchar(25) NOT NULL,   
	Address1 varchar(25) NOT NULL,
	Address2 varchar(25) DEFAULT 'Unknown', 
	City varchar(15) NOT NULL,
	[State] char(2) NOT NULL,
	Zip varchar(10) NOT NULL,
	Contact varchar(25) NOT NULL,
	Phone char(10) NOT NULL,
	FedIDNo  varchar(10) NOT NULL,
	DateInSystem smalldatetime NOT NULL 
);
GO
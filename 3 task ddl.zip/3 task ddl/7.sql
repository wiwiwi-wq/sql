SELECT * FROM Customers;
GO
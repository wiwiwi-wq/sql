﻿INSERT INTO Customers																			   
(CustomerName, Address1, City, Contact, Phone)
VALUES
('Ïåòðåíêî Ïåòð Ïåòðîâè÷', 'Ëóãàíñêàÿ 25', 'Êîíîòîï', 'PetrPetrenko@mail.ru', '(093)1231212')

DBCC CHECKIDENT("Customers",RESEED,2) 
GO
DBCC CHECKIDENT("Orders",RESEED,0); 
GO

INSERT INTO Orders
(CustomerNo, OrderDate,	EmployeeId)
VALUES (1,GETDATE(),1);
GO
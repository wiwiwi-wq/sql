SELECT * FROM Customers
GO
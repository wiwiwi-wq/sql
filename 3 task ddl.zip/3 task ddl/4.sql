ALTER DATABASE ShopDB   
MODIFY FILE					
( NAME = 'ShopDB',
  SIZE = 100MB )		 
GO

EXEC sp_helpdb ShopDB